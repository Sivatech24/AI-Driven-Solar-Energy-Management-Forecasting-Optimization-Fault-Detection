from .model import train_model, build_dense_model  # Make sure this is correct

